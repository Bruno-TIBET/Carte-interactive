import { FranceMap } from "@/components/france-map"
import { ThemeProvider } from "@/components/theme-provider"

export default function Home() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
      <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-background">
        <div className="max-w-5xl w-full space-y-6">
          <h1 className="text-3xl font-bold text-center">Carte Interactive de France</h1>
          <p className="text-center text-muted-foreground">Cliquez sur une région pour découvrir plus d'informations</p>
          <p className="text-center text-sm text-muted-foreground">
            Double-cliquez sur une région pour voir ses départements avec leurs numéros
          </p>
          <FranceMap />
        </div>
      </main>
    </ThemeProvider>
  )
}

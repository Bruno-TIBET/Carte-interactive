"use client"

import { useState } from "react"
import { RegionModal } from "./region-modal"
import { DepartmentModal } from "./department-modal"
import { regions } from "@/lib/regions-data"
import { departments } from "@/lib/departments-data"
import { ChevronLeft } from "lucide-react"
import { Button } from "./ui/button"

export function FranceMap() {
  const [selectedRegion, setSelectedRegion] = useState<(typeof regions)[number] | null>(null)
  const [selectedDepartment, setSelectedDepartment] = useState<(typeof departments)[number] | null>(null)
  const [isRegionModalOpen, setIsRegionModalOpen] = useState(false)
  const [isDepartmentModalOpen, setIsDepartmentModalOpen] = useState(false)
  const [viewMode, setViewMode] = useState<"regions" | "departments">("regions")
  const [focusedRegionId, setFocusedRegionId] = useState<number | null>(null)

  const handleRegionClick = (region: (typeof regions)[number]) => {
    setSelectedRegion(region)
    setIsRegionModalOpen(true)
  }

  const handleDepartmentClick = (department: (typeof departments)[number]) => {
    setSelectedDepartment(department)
    setIsDepartmentModalOpen(true)
  }

  const showDepartmentsForRegion = (region: (typeof regions)[number]) => {
    setSelectedRegion(region)
    setFocusedRegionId(region.id)
    setViewMode("departments")
    setIsRegionModalOpen(false)
  }

  const backToRegions = () => {
    setViewMode("regions")
    setFocusedRegionId(null)
  }

  // Filtrer les départements par région sélectionnée
  const filteredDepartments = focusedRegionId
    ? departments.filter((dept) => dept.regionId === focusedRegionId)
    : departments

  return (
    <div className="relative w-full aspect-[4/4] md:aspect-[4/3.5] bg-white rounded-lg shadow-md p-4">
      {viewMode === "departments" && (
        <div className="absolute top-4 left-4 z-10">
          <Button variant="outline" size="sm" onClick={backToRegions} className="flex items-center gap-1">
            <ChevronLeft className="h-4 w-4" />
            Retour aux régions
          </Button>
        </div>
      )}

      {viewMode === "departments" && selectedRegion && (
        <div className="absolute top-4 right-4 bg-white/90 p-2 rounded-md">
          <h2 className="font-semibold text-sm sm:text-base">Départements : {selectedRegion.name}</h2>
        </div>
      )}

      {viewMode === "regions" ? (
        <svg viewBox="0 0 600 600" className="w-full h-full" aria-label="Carte des régions de France">
          {regions.map((region) => (
            <path
              key={region.id}
              d={region.path}
              fill={region.color}
              stroke="#fff"
              strokeWidth="2"
              className="region transition-all duration-300 hover:brightness-110 hover:stroke-gray-800 hover:stroke-[3] cursor-pointer"
              aria-label={region.name}
              onClick={() => handleRegionClick(region)}
              onDoubleClick={() => showDepartmentsForRegion(region)}
            />
          ))}

          {/* Ajouter les noms des régions */}
          {regions.map((region) => (
            <text
              key={`text-${region.id}`}
              x={region.labelPosition?.x || 0}
              y={region.labelPosition?.y || 0}
              textAnchor="middle"
              fontSize="12"
              fill="#333"
              className="pointer-events-none font-semibold"
            >
              {region.name}
            </text>
          ))}
        </svg>
      ) : (
        <svg viewBox="0 0 600 600" className="w-full h-full" aria-label={`Départements de ${selectedRegion?.name}`}>
          {filteredDepartments.map((department) => (
            <path
              key={department.id}
              d={department.path}
              fill={department.color || "#e5e5e5"}
              stroke="#fff"
              strokeWidth="1"
              className="transition-all duration-300 hover:brightness-110 hover:stroke-gray-800 hover:stroke-[2] cursor-pointer"
              aria-label={department.name}
              onClick={() => handleDepartmentClick(department)}
            />
          ))}

          {/* Ajouter les numéros des départements */}
          {filteredDepartments.map((department) => (
            <text
              key={`text-${department.id}`}
              x={department.labelPosition?.x || 0}
              y={department.labelPosition?.y || 0}
              textAnchor="middle"
              fontSize="10"
              fontWeight="bold"
              fill="#333"
              className="pointer-events-none"
            >
              {department.code}
            </text>
          ))}
        </svg>
      )}

      {/* Légende */}
      <div className="absolute bottom-4 right-4 bg-white/80 p-2 rounded-md text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold">Légende:</span>
        </div>
        {viewMode === "regions" ? (
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1">
            {regions.slice(0, 6).map((region) => (
              <div key={region.id} className="flex items-center gap-1">
                <div className="w-3 h-3" style={{ backgroundColor: region.color }}></div>
                <span>{region.name}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-1 max-h-40 overflow-y-auto">
            {filteredDepartments.map((department) => (
              <div key={department.id} className="flex items-center gap-1">
                <div className="w-3 h-3" style={{ backgroundColor: department.color }}></div>
                <span>
                  {department.code} - {department.name}
                </span>
              </div>
            ))}
          </div>
        )}
        {viewMode === "regions" && (
          <div className="mt-2 text-xs text-muted-foreground">
            Double-cliquez sur une région pour voir ses départements
          </div>
        )}
      </div>

      <RegionModal
        region={selectedRegion}
        isOpen={isRegionModalOpen}
        onClose={() => setIsRegionModalOpen(false)}
        onShowDepartments={showDepartmentsForRegion}
      />

      <DepartmentModal
        department={selectedDepartment}
        isOpen={isDepartmentModalOpen}
        onClose={() => setIsDepartmentModalOpen(false)}
      />
    </div>
  )
}

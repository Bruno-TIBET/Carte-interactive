"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import type { departments } from "@/lib/departments-data"
import { regions } from "@/lib/regions-data"

interface DepartmentModalProps {
  department: (typeof departments)[number] | null
  isOpen: boolean
  onClose: () => void
}

export function DepartmentModal({ department, isOpen, onClose }: DepartmentModalProps) {
  if (!department) return null

  const region = regions.find((r) => r.id === department.regionId)

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            {department.name}
            <span className="text-sm font-normal bg-gray-100 px-2 py-1 rounded-md">{department.code}</span>
          </DialogTitle>
          <DialogDescription>
            <div className="flex items-center gap-2 mt-1">
              <span>Département de {region?.name || "France"}</span>
            </div>
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-1">À propos</h3>
            <p className="text-sm text-muted-foreground">{department.description}</p>
          </div>

          <div>
            <h3 className="font-medium mb-1">Informations</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Préfecture:</span>
                <p>{department.prefecture}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Population:</span>
                <p>{department.population.toLocaleString("fr-FR")}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Superficie:</span>
                <p>{department.area.toLocaleString("fr-FR")} km²</p>
              </div>
              <div>
                <span className="text-muted-foreground">Code:</span>
                <p>{department.code}</p>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="outline" size="sm" className="gap-1" asChild>
              <a href={department.website} target="_blank" rel="noopener noreferrer">
                Visiter le site <ExternalLink className="h-3 w-3" />
              </a>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

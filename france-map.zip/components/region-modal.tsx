"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ExternalLink, Map } from "lucide-react"
import type { regions } from "@/lib/regions-data"

interface RegionModalProps {
  region: (typeof regions)[number] | null
  isOpen: boolean
  onClose: () => void
  onShowDepartments: (region: (typeof regions)[number]) => void
}

export function RegionModal({ region, isOpen, onClose, onShowDepartments }: RegionModalProps) {
  if (!region) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl">{region.name}</DialogTitle>
          <DialogDescription>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-4 h-4 rounded-full" style={{ backgroundColor: region.color }}></div>
              <span>Région {region.id}</span>
            </div>
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-1">À propos</h3>
            <p className="text-sm text-muted-foreground">{region.description}</p>
          </div>

          <div>
            <h3 className="font-medium mb-1">Informations</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Préfecture:</span>
                <p>{region.prefecture}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Population:</span>
                <p>{region.population.toLocaleString("fr-FR")}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Superficie:</span>
                <p>{region.area.toLocaleString("fr-FR")} km²</p>
              </div>
              <div>
                <span className="text-muted-foreground">Départements:</span>
                <p>{region.departments}</p>
              </div>
            </div>
          </div>

          <div className="flex justify-between">
            <Button variant="outline" size="sm" className="gap-1" onClick={() => onShowDepartments(region)}>
              <Map className="h-4 w-4 mr-1" />
              Voir les départements
            </Button>

            <Button variant="outline" size="sm" className="gap-1" asChild>
              <a href={region.website} target="_blank" rel="noopener noreferrer">
                Visiter le site <ExternalLink className="h-3 w-3" />
              </a>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
